"""oracle-plus-v1 toggles return a legal action."""

from __future__ import annotations

from monopoly_bench.engine import SharedGame, clone_env
from monopoly_game_engine.constants import COLOR_GROUPS
from oracle.agent import OracleConfig
from oracle.eval_h2h import ORACLE_PLUS_ID, PLUS_FIELD_LINEUP, _is_oracle_policy, _parse_lineup
from oracle.plus_agent import OraclePlusAgent, denial_value, resolve_plus_config


def test_plus_id_is_oracle_policy():
    assert _is_oracle_policy(ORACLE_PLUS_ID)
    assert PLUS_FIELD_LINEUP[0] == ORACLE_PLUS_ID
    assert len(_parse_lineup(",".join(PLUS_FIELD_LINEUP))) == 4


def test_resolve_plus_defaults_networth_and_all_on():
    cfg = resolve_plus_config(OracleConfig())
    assert cfg.leaf == "asu"
    assert cfg.one_ply is True
    assert cfg.solvency is False
    assert cfg.denial is True
    assert cfg.completing_trade is True
    assert cfg.auction is True
    assert cfg.inncenta_trade is True
    assert cfg.networth_mix == 0.0
    assert cfg.auction_kind == "inncenta"
    assert cfg.family_body == "one_ply"
    assert cfg.one_ply_trades is False
    assert cfg.phase_switch is False


def test_explicit_off_survives():
    cfg = resolve_plus_config(
        OracleConfig(one_ply=False, denial=False, auction=False, inncenta_trade=False, leaf="asu")
    )
    assert cfg.one_ply is False
    assert cfg.denial is False
    assert cfg.auction is False
    assert cfg.inncenta_trade is False
    assert cfg.leaf == "asu"
    assert cfg.solvency is False


def test_plus_agent_legal_and_non_mutating():
    game = SharedGame.new(9, max_rounds=20)
    before = clone_env(game.env)
    actor = game.env.whose_turn()
    agent = OraclePlusAgent(actor, OracleConfig(leaf="networth"), seed=0)
    action = agent.choose_action(game.env)
    assert action in before.get_allowed_actions(actor)
    assert game.env.round == before.round


def test_greedy_toggle_still_legal():
    game = SharedGame.new(10, max_rounds=20)
    actor = game.env.whose_turn()
    agent = OraclePlusAgent(
        actor,
        OracleConfig(one_ply=False, solvency=True, denial=True, completing_trade=True),
        seed=1,
    )
    assert agent.choose_action(game.env) in game.env.get_allowed_actions(actor)


def test_denial_zero_without_opponent_presence():
    game = SharedGame.new(11, max_rounds=20)
    env = game.env
    # Fresh board: nobody owns brown. Denial of Mediterranean should be 0.
    assert denial_value(env, 0, 1) == 0.0
    # Give an opponent one brown deed.
    brown = COLOR_GROUPS["brown"]
    env.properties[brown[0]].owner = 1
    if env.properties[brown[0]] not in env.players[1].properties:
        env.players[1].properties.append(env.properties[brown[0]])
    assert denial_value(env, 0, brown[1]) > 0.0


def test_auction_skips_when_not_in_auction():
    game = SharedGame.new(12, max_rounds=20)
    actor = game.env.whose_turn()
    agent = OraclePlusAgent(actor, OracleConfig(leaf="networth"), seed=0)
    legal = list(game.env.get_allowed_actions(actor))
    assert agent._auction_action(game.env, legal) is None


def test_auction_bids_when_headroom_exists():
    from monopoly_game_engine.actions import AuctionAction
    from monopoly_game_engine.env import PHASE_AUCTION

    game = SharedGame.new(13, max_rounds=20)
    env = game.env
    brown = COLOR_GROUPS["brown"]
    env.phase = PHASE_AUCTION
    env.auction_property_id = brown[1]
    env.auction_current_pid = 0
    env.auction_bidders = [0, 1, 2, 3]
    env.auction_high_bid = 0
    env.auction_highest_bidder = None
    env.properties[brown[0]].owner = 0
    if env.properties[brown[0]] not in env.players[0].properties:
        env.players[0].properties.append(env.properties[brown[0]])
    agent = OraclePlusAgent(0, OracleConfig(leaf="networth"), seed=0)
    legal = list(env.get_allowed_actions(0))
    bid = agent._auction_action(env, legal)
    assert bid is not None
    assert bid in legal
    assert bid != int(AuctionAction.PASS)
    before_cash = env.players[0].cash
    action = agent.choose_action(env)
    assert action == bid
    assert env.players[0].cash == before_cash


def test_no_auction_still_legal_in_auction_phase():
    from monopoly_game_engine.env import PHASE_AUCTION

    game = SharedGame.new(14, max_rounds=20)
    env = game.env
    env.phase = PHASE_AUCTION
    env.auction_property_id = 1
    env.auction_current_pid = 0
    env.auction_bidders = [0, 1, 2, 3]
    env.auction_high_bid = 0
    agent = OraclePlusAgent(
        0, OracleConfig(leaf="networth", auction=False, one_ply=True), seed=0
    )
    action = agent.choose_action(env)
    assert action in env.get_allowed_actions(0)


def _auction_env(seed: int = 20):
    from monopoly_game_engine.env import PHASE_AUCTION

    game = SharedGame.new(seed, max_rounds=20)
    env = game.env
    brown = COLOR_GROUPS["brown"]
    env.phase = PHASE_AUCTION
    env.auction_property_id = brown[1]
    env.auction_current_pid = 0
    env.auction_bidders = [0, 1, 2, 3]
    env.auction_high_bid = 0
    env.auction_highest_bidder = None
    env.properties[brown[0]].owner = 0
    if env.properties[brown[0]] not in env.players[0].properties:
        env.players[0].properties.append(env.properties[brown[0]])
    return env


def test_alinebidal_auction_returns_legal():
    env = _auction_env(21)
    agent = OraclePlusAgent(
        0, OracleConfig(leaf="networth", auction=True, auction_kind="alinebidal"), seed=0
    )
    action = agent.choose_action(env)
    assert action in env.get_allowed_actions(0)


def test_slayer_auction_returns_legal():
    env = _auction_env(22)
    agent = OraclePlusAgent(
        0, OracleConfig(leaf="networth", auction=True, auction_kind="slayer"), seed=0
    )
    action = agent.choose_action(env)
    assert action in env.get_allowed_actions(0)


def test_slayer_body_and_phase_switch_legal():
    game = SharedGame.new(23, max_rounds=20)
    actor = game.env.whose_turn()
    agent = OraclePlusAgent(
        actor,
        OracleConfig(
            leaf="networth",
            family_body="slayer",
            phase_switch=True,
            one_ply_trades=True,
            auction_kind="alinebidal",
        ),
        seed=0,
    )
    action = agent.choose_action(game.env)
    assert action in game.env.get_allowed_actions(actor)

