"""Steal Alinebidal / Slayer family policies for oracle-plus-v1 toggles."""

from __future__ import annotations

from monopoly_game_engine.actions import OFFSETS, ActionType
from monopoly_game_engine.env import PHASE_AUCTION, MonopolyEnv

TRADE_LO = OFFSETS["buy_trade"]
AUCTION_LO = OFFSETS["auction"]
AUCTION_KINDS = ("inncenta", "alinebidal", "slayer")
FAMILY_BODIES = ("one_ply", "slayer", "alinebidal")


def board_developed(env: MonopolyEnv) -> bool:
    for prop in env.properties.values():
        if getattr(prop, "houses", 0) > 0:
            return True
        if getattr(prop, "is_monopoly", False):
            return True
    return False


def has_trade_action(legal: list[int]) -> bool:
    accept = int(ActionType.ACCEPT_TRADE)
    decline = int(ActionType.DECLINE_TRADE)
    return any(a in (accept, decline) or TRADE_LO <= a < AUCTION_LO for a in legal)


_AB: dict[int, object] = {}
_SL: dict[int, object] = {}


def _alinebidal_agent(player_id: int):
    agent = _AB.get(player_id)
    if agent is None:
        from competitors.factory import _ensure_alinebidal_path

        _ensure_alinebidal_path()
        from competition_agent.final_agent import FinalAgent

        agent = FinalAgent(player_id, rng_seed=player_id)
        _AB[player_id] = agent
    return agent


def _slayer_agent(player_id: int):
    agent = _SL.get(player_id)
    if agent is None:
        from competitors.asu_slayer import SlayerV1

        agent = SlayerV1(player_id)
        _SL[player_id] = agent
    return agent


def alinebidal_auction(env: MonopolyEnv, player_id: int, legal: list[int]) -> int | None:
    if env.phase != PHASE_AUCTION:
        return None
    agent = _alinebidal_agent(player_id)
    allowed = set(legal)
    action = agent.policy._auction(env, player_id, allowed, legal)
    if action is None:
        return None
    return int(action) if int(action) in allowed else None


def slayer_auction(env: MonopolyEnv, player_id: int, legal: list[int]) -> int | None:
    if env.phase != PHASE_AUCTION:
        return None
    action = int(_slayer_agent(player_id)._auction_action(env, set(legal)))
    return action if action in legal else None


def family_action(kind: str, env: MonopolyEnv, player_id: int, legal: list[int]) -> int | None:
    if kind == "slayer":
        action = int(_slayer_agent(player_id).choose_action(env))
    elif kind == "alinebidal":
        action = int(_alinebidal_agent(player_id).choose_action(env))
    else:
        return None
    return action if action in legal else None
