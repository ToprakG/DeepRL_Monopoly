"""Competitor agents return a legal action on a fresh env."""

from __future__ import annotations

from competitors.factory import COMPETITOR_IDS, build_competitor
from monopoly_game_engine.env import MonopolyEnv
from oracle.eval_h2h import COMPETITOR_LINEUP, ORACLE_V2_ID
from ASU_FROZEN_TEACHER.evaluate import AgentSpec, _run_game


def test_competitor_ids_fill_the_field_lineup():
    assert COMPETITOR_LINEUP[0] == ORACLE_V2_ID
    assert set(COMPETITOR_LINEUP[1:]) == set(COMPETITOR_IDS)


def test_each_competitor_returns_a_legal_opening_action():
    env = MonopolyEnv(agent_ids=[0], max_rounds=5)
    for policy_id in COMPETITOR_IDS:
        agent = build_competitor(policy_id, 0)
        legal = set(env.get_allowed_actions(0))
        action = agent.choose_action(env)
        assert action in legal, f"{policy_id} chose {action} not in {legal}"


class _EndTurnFactory:
    def build(self, spec, player_id):
        class _Agent:
            fallbacks = 0

            def choose_action(self, env):
                from monopoly_game_engine.actions import ActionType

                allowed = env.get_allowed_actions(player_id)
                if int(ActionType.END_TURN) in allowed:
                    return int(ActionType.END_TURN)
                return allowed[0]

        return _Agent()


def test_game_timeout_truncates_immediately():
    specs = tuple(AgentSpec("fixed-a", "fixed-a") for _ in range(4))
    result = _run_game(specs, 0, 0, 20_000, _EndTurnFactory(), game_timeout_s=0.0)
    assert result["truncated"] is True
    assert result["timed_out"] is True
    assert result["winner"] is None
    assert result["decisions"] == 0



def test_competitor_ids_fill_the_field_lineup():
    assert COMPETITOR_LINEUP[0] == ORACLE_V2_ID
    assert set(COMPETITOR_LINEUP[1:]) == set(COMPETITOR_IDS)


def test_each_competitor_returns_a_legal_opening_action():
    env = MonopolyEnv(agent_ids=[0], max_rounds=5)
    for policy_id in COMPETITOR_IDS:
        agent = build_competitor(policy_id, 0)
        legal = set(env.get_allowed_actions(0))
        action = agent.choose_action(env)
        assert action in legal, f"{policy_id} chose {action} not in {legal}"
