"""Vendored competitor agents for oracle head-to-heads."""

from .factory import (
    ALINEBIDAL_ID,
    BOOM_ID,
    COMPETITOR_IDS,
    INNCENTA_ID,
    build_competitor,
)

__all__ = [
    "ALINEBIDAL_ID",
    "BOOM_ID",
    "COMPETITOR_IDS",
    "INNCENTA_ID",
    "build_competitor",
]
