"""Toggleable 1-ply policy that steals the competitor pieces that actually won.

Flags (all default on for ``oracle-plus-v1``):
- ``one_ply`` — deepcopy legal shortlist, pick max own-score (Inncenta shape)
- ``solvency`` — prefer successors that still pay worst reachable rent (default off;
  shipped Inncenta has this gate off)
- ``denial`` — add Alinebidal-style block value for deeds opponents need
- ``completing_trade`` — take a monopoly-completing buy-trade before search
- ``auction`` — run an auction heuristic before 1-ply (default on)
- ``auction_kind`` — inncenta (legacy) / asu_delta (our scorer swing)
- ``cash_gate`` — 1-ply penalizes futures below live opponent rent
- ``build_first`` — cheapest legal house/hotel if the live-rent floor holds
- ``race_buy`` — buy when we already have a colour or an opponent does
- ``lethal_jail`` — skip bail when published rent is a large fraction of cash
- ``one_ply_trades`` — 1-ply only when a trade is legal (default off)
- ``inncenta_trade`` — Inncenta completing-trade: quality rank, pay-up first
- ``networth_mix`` — blend own-score toward raw net worth (0 = off)
- ``leaf`` — own-score: asu (default) / networth / asu_plus / clone / rollout
"""

from __future__ import annotations

import random
from dataclasses import replace

from monopoly_game_engine.actions import AUCTION_ACTION_TO_INCREMENT, OFFSETS, ActionType
from monopoly_game_engine.agents_fixed import _buy_trade_action
from monopoly_game_engine.constants import COLOR_GROUPS, PROPERTIES, TRADE_CASH_LEVELS
from monopoly_game_engine.env import PHASE_AUCTION, MonopolyEnv

from oracle.agent import OracleConfig
from oracle.plus_steals import (
    AUCTION_KINDS,
    asu_delta_auction,
    build_first_action,
    cash_floor,
    has_trade_action,
    lethal_jail_action,
    race_buy_action,
)
from oracle.rollout_policy import greedy_rollout_action
from oracle_v2.clone import fast_clone_env

ORACLE_PLUS_ID = "oracle-plus-v1"
TRADE_LO = OFFSETS["buy_trade"]
AUCTION_LO = OFFSETS["auction"]
MAX_TRADE_CANDIDATES = 12
MAX_CANDIDATES = 60
CASH_FLOOR = 200.0


def _flag(value: bool | None, default: bool = True) -> bool:
    return default if value is None else bool(value)


def resolve_plus_config(config: OracleConfig) -> OracleConfig:
    """Fill unspecified plus toggles. Default leaf is ASU (Inncenta's scorer)."""

    leaf = config.leaf if config.leaf and config.leaf != "rollout" else "asu"
    kind = (config.auction_kind or "inncenta").strip().lower()
    if kind not in AUCTION_KINDS:
        kind = "inncenta"
    return replace(
        config,
        leaf=leaf,
        one_ply=_flag(config.one_ply, True),
        solvency=_flag(config.solvency, False),
        denial=_flag(config.denial, True),
        completing_trade=_flag(config.completing_trade, True),
        auction=_flag(config.auction, True),
        inncenta_trade=_flag(config.inncenta_trade, True),
        networth_mix=float(config.networth_mix or 0.0),
        auction_kind=kind,
        family_body="one_ply",
        one_ply_trades=_flag(config.one_ply_trades, False),
        phase_switch=False,
        cash_gate=_flag(config.cash_gate, False),
        build_first=_flag(config.build_first, False),
        race_buy=_flag(config.race_buy, False),
        lethal_jail=_flag(config.lethal_jail, False),
    )


def denial_value(env: MonopolyEnv, pid: int, square: int) -> float:
    """What holding ``square`` denies opponents (Alinebidal B5)."""

    data = PROPERTIES.get(square)
    if data is None:
        return 0.0
    group = COLOR_GROUPS.get(data["color"]) or ()
    size = len(group)
    if size < 2:
        return 0.0
    rents = data.get("rent") or [data.get("price", 0)]
    hotel = float(rents[-1])
    total = 0.0
    for opp in env.players:
        if opp.player_id == pid or opp.bankrupt:
            continue
        owned = sum(1 for sq in group if env.properties[sq].owner == opp.player_id)
        if owned == 0:
            continue
        missing_after = size - (owned + 1)
        if missing_after < 0:
            continue
        closeness = (owned + 1) / size
        total += (hotel / (2 ** missing_after)) * closeness
    return total


def _acquired_square(env: MonopolyEnv, pid: int, action: int) -> int | None:
    if action == int(ActionType.BUY_PROPERTY):
        return int(env.players[pid].position)
    if AUCTION_LO <= action < AUCTION_LO + 8:
        square = getattr(env, "auction_property_id", None)
        return None if square is None else int(square)
    return None


def _own_score(env: MonopolyEnv, pid: int, config: OracleConfig) -> float:
    player = env.players[pid]
    if player.bankrupt:
        return -1.0e9
    kind = config.leaf
    if kind == "asu":
        from ASU_FROZEN_TEACHER import evaluate_value

        score = float(evaluate_value(env, pid).total)
    elif kind == "asu_plus":
        from asu_plus import evaluate_value_plus

        score = float(evaluate_value_plus(env, pid).total)
    elif kind in ("clone", "rollout"):
        from oracle.leaves import build_leaf_fn

        score = float(build_leaf_fn(config)(env)[pid])
    else:
        score = float(player.net_worth())
    mix = min(1.0, max(0.0, float(config.networth_mix or 0.0)))
    if mix <= 0.0:
        return score
    return (1.0 - mix) * score + mix * float(player.net_worth())


class OraclePlusAgent:
    """H2H ``choose_action(env)`` policy with steal-toggles."""

    policy_id = ORACLE_PLUS_ID

    def __init__(self, player_id: int, config: OracleConfig | None = None, *, seed: int = 0):
        self.player_id = player_id
        self.config = resolve_plus_config(config or OracleConfig())
        self.rng = random.Random(0xC0FFEE + int(seed) + player_id)

    def _shortlist(self, legal: list[int]) -> list[int]:
        if len(legal) <= MAX_CANDIDATES:
            return legal
        trades, others = [], []
        for action in legal:
            (trades if TRADE_LO <= action < AUCTION_LO else others).append(action)
        picked = others[: MAX_CANDIDATES - MAX_TRADE_CANDIDATES]
        if trades:
            k = min(MAX_TRADE_CANDIDATES, len(trades), MAX_CANDIDATES - len(picked))
            picked.extend(self.rng.sample(trades, k))
        return picked or legal[:MAX_CANDIDATES]

    def _property_worth(self, env: MonopolyEnv, square: int) -> float:
        from competitors.inncenta import evaluator as EV

        prop = env.properties.get(square)
        if prop is None:
            return 0.0
        rivals = sum(
            1 for i, p in enumerate(env.players) if i != self.player_id and not p.bankrupt
        )
        worth = EV.W_INCOME * EV.B.expected_rent(square, 0, False) * max(rivals, 1)
        colour = getattr(prop, "color", None)
        group = EV.B.SETS.get(colour)
        if group:
            mine = sum(1 for s in group if env.properties[s].owner == self.player_id)
            if mine == len(group) - 1:
                worth += EV.W_POTENT * sum(
                    EV.B.expected_rent(s, EV.BUILD_TARGET, True) for s in group
                ) * max(rivals, 1)
        return worth

    def _auction_action(self, env: MonopolyEnv, legal: list[int]) -> int | None:
        from competitors.inncenta import evaluator as EV

        bids = [a for a in legal if AUCTION_LO < a < AUCTION_LO + 5]
        if not bids:
            return None
        square = getattr(env, "auction_property_id", None)
        if square is None:
            return None
        worth = self._property_worth(env, int(square))
        high = float(getattr(env, "auction_high_bid", 0) or 0)
        cash = env.players[self.player_id].cash
        frac = getattr(EV, "AUCTION_RESERVE_FRAC", None)
        reserve = EV.CASH_FLOOR if frac is None else max(50.0, frac * cash)
        headroom = min(worth, cash - reserve) - high
        if headroom <= 0:
            return None
        for action, step in sorted(AUCTION_ACTION_TO_INCREMENT.items(), key=lambda kv: -kv[1]):
            if int(action) in bids and step <= headroom:
                return int(action)
        return None

    def _completing_trade(self, env: MonopolyEnv, legal: list[int]) -> int | None:
        pid = self.player_id
        me = env.players[pid]
        prices = (2, 1, 0) if self.config.inncenta_trade else (0, 1, 2)
        best: tuple[float, int] | None = None
        if self.config.inncenta_trade:
            from competitors.inncenta import evaluator as EV

            groups = EV.B.SETS.items()
            quality = EV.B.set_quality()
        else:
            groups = (
                (color, group)
                for color, group in COLOR_GROUPS.items()
                if color not in ("railroad", "utility")
            )
            quality = {}
        for color, group in groups:
            owned = [sq for sq in group if env.properties[sq].owner == pid]
            if len(owned) + 1 != len(group):
                continue
            need = [
                sq
                for sq in group
                if env.properties[sq].owner not in (pid, None)
                and not env.players[env.properties[sq].owner].bankrupt
                and env.properties[sq].houses == 0
            ]
            if not need:
                continue
            sq = need[0]
            target = env.properties[sq].owner
            for price_idx in prices:
                cost = float(PROPERTIES[sq]["price"]) * TRADE_CASH_LEVELS[price_idx]
                if me.cash - cost < CASH_FLOOR:
                    continue
                action = _buy_trade_action(pid, target, sq, price_idx, env, legal)
                if action is None:
                    continue
                if not self.config.inncenta_trade:
                    return int(action)
                rank = float(quality.get(color, 0.0))
                if best is None or rank > best[0]:
                    best = (rank, int(action))
                break
        return None if best is None else best[1]

    def _survives(self, future: MonopolyEnv) -> bool:
        if not self.config.solvency:
            return True
        from competitors.inncenta.evaluator import is_solvent

        try:
            return bool(is_solvent(future, self.player_id))
        except Exception:
            return True

    def _score(self, env: MonopolyEnv, action: int, future: MonopolyEnv) -> float:
        value = _own_score(future, self.player_id, self.config)
        if self.config.cash_gate:
            cash = float(future.players[self.player_id].cash)
            if cash < cash_floor(future, self.player_id):
                value -= 1.0e6
        if self.config.denial:
            square = _acquired_square(env, self.player_id, action)
            if square is not None:
                value += float(self.config.denial_weight) * denial_value(
                    env, self.player_id, square
                )
        return value

    def _one_ply(self, env: MonopolyEnv, legal: list[int]) -> int:
        best_action, best_value = legal[0], float("-inf")
        safe_action, safe_value = None, float("-inf")
        state = random.getstate()
        try:
            for action in self._shortlist(legal):
                try:
                    future = fast_clone_env(env)
                    future.step(action)
                except Exception:
                    continue
                value = self._score(env, action, future)
                if value > best_value:
                    best_action, best_value = action, value
                if self._survives(future) and value > safe_value:
                    safe_action, safe_value = action, value
        finally:
            random.setstate(state)
        if safe_action is not None:
            return int(safe_action)
        return int(best_action)

    def choose_action(self, env: MonopolyEnv) -> int:
        legal = list(env.get_allowed_actions(self.player_id))
        if not legal:
            return int(ActionType.END_TURN)
        if len(legal) == 1:
            return int(legal[0])
        if self.config.lethal_jail:
            jail = lethal_jail_action(env, self.player_id, legal)
            if jail is not None:
                return jail
        if self.config.build_first:
            built = build_first_action(env, self.player_id, legal)
            if built is not None:
                return built
        if self.config.race_buy:
            buy = race_buy_action(env, self.player_id, legal)
            if buy is not None:
                return buy
        if self.config.auction:
            if self.config.auction_kind == "asu_delta":
                bid = asu_delta_auction(env, self.player_id, legal)
            else:
                bid = self._auction_action(env, legal)
            if bid is not None:
                return bid
            if getattr(env, "phase", None) == PHASE_AUCTION:
                if self.config.one_ply:
                    action = self._one_ply(env, legal)
                    return action if action in legal else int(legal[0])
                return int(legal[0])
        if self.config.completing_trade:
            trade = self._completing_trade(env, legal)
            if trade is not None:
                return trade
        if self.config.one_ply and (
            not self.config.one_ply_trades or has_trade_action(legal)
        ):
            action = self._one_ply(env, legal)
            return action if action in legal else int(legal[0])
        action = int(greedy_rollout_action(env, self.player_id))
        if action in legal:
            return action
        if int(ActionType.END_TURN) in legal:
            return int(ActionType.END_TURN)
        return int(legal[0])


__all__ = [
    "ORACLE_PLUS_ID",
    "OraclePlusAgent",
    "denial_value",
    "resolve_plus_config",
]
