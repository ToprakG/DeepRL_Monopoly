"""Original plus-agent rules, from our H2H logs — not competitor code.

On the real table (96 games) we went bankrupt 60 times. Fast wins were
wipeouts after we actually built. These helpers are ours:

- live-rent cash floor (hotels that exist *now*, not a copied solvency gate)
- ASU-delta auction (counterfactual our scorer, not their deed formulas)
- build-first when a house is legal and the floor still holds
- race-buy when a colour is already contested
- lethal-jail: skip bail if published rent would wreck us
"""

from __future__ import annotations

from monopoly_game_engine.actions import (
    AUCTION_ACTION_TO_INCREMENT,
    OFFSETS,
    ActionType,
    AuctionAction,
)
from monopoly_game_engine.constants import COLOR_GROUPS, PROPERTIES, REAL_ESTATE_IDS
from monopoly_game_engine.env import PHASE_AUCTION, MonopolyEnv

AUCTION_KINDS = ("inncenta", "asu_delta")
HOUSE_LO = OFFSETS["improve_house"]
HOTEL_LO = OFFSETS["improve_hotel"]
SELL_HOUSE_LO = OFFSETS["sell_house"]
TRADE_LO = OFFSETS["buy_trade"]
AUCTION_LO = OFFSETS["auction"]


def has_trade_action(legal: list[int]) -> bool:
    accept = int(ActionType.ACCEPT_TRADE)
    decline = int(ActionType.DECLINE_TRADE)
    return any(a in (accept, decline) or TRADE_LO <= a < AUCTION_LO for a in legal)


def max_live_rent(env: MonopolyEnv, pid: int) -> float:
    """Highest rent an opponent can charge on the current board."""

    worst = 0.0
    for opp in env.players:
        if opp.player_id == pid or opp.bankrupt:
            continue
        rails = sum(1 for p in opp.properties if p.color == "railroad" and not p.mortgaged)
        utils = sum(1 for p in opp.properties if p.color == "utility" and not p.mortgaged)
        for prop in opp.properties:
            rent = float(prop.get_rent(7, max(rails, 1), max(utils, 1)))
            if rent > worst:
                worst = rent
    return worst


def cash_floor(env: MonopolyEnv, pid: int) -> float:
    return max(50.0, max_live_rent(env, pid))


def lethal_jail_action(env: MonopolyEnv, pid: int, legal: list[int]) -> int | None:
    if int(ActionType.PAY_BAIL) not in legal:
        return None
    cash = float(env.players[pid].cash)
    if max_live_rent(env, pid) < 0.45 * max(cash, 1.0):
        return None
    if int(ActionType.USE_GOOJ_CARD) in legal:
        return int(ActionType.USE_GOOJ_CARD)
    if int(ActionType.ROLL_DICE) in legal:
        return int(ActionType.ROLL_DICE)
    if int(ActionType.END_TURN) in legal:
        return int(ActionType.END_TURN)
    return None


def build_first_action(env: MonopolyEnv, pid: int, legal: list[int]) -> int | None:
    floor = cash_floor(env, pid)
    cash = float(env.players[pid].cash)
    best: tuple[float, int] | None = None
    for action in legal:
        if HOUSE_LO <= action < HOTEL_LO:
            square = REAL_ESTATE_IDS[action - HOUSE_LO]
            cost = float(PROPERTIES[square]["house_price"])
        elif HOTEL_LO <= action < SELL_HOUSE_LO:
            square = REAL_ESTATE_IDS[action - HOTEL_LO]
            cost = float(PROPERTIES[square]["house_price"])
        else:
            continue
        if cash - cost < floor:
            continue
        if best is None or cost < best[0]:
            best = (cost, int(action))
    return None if best is None else best[1]


def race_buy_action(env: MonopolyEnv, pid: int, legal: list[int]) -> int | None:
    if int(ActionType.BUY_PROPERTY) not in legal:
        return None
    square = int(env.players[pid].position)
    prop = env.properties.get(square)
    if prop is None or prop.owner is not None:
        return None
    price = float(prop.price)
    if float(env.players[pid].cash) - price < cash_floor(env, pid):
        return None
    group = COLOR_GROUPS.get(prop.color) or ()
    ours = sum(1 for sq in group if env.properties[sq].owner == pid)
    opps = {
        env.properties[sq].owner
        for sq in group
        if env.properties[sq].owner not in (pid, None)
    }
    if ours < 1 and not opps:
        return None
    return int(ActionType.BUY_PROPERTY)


def asu_delta_auction(env: MonopolyEnv, pid: int, legal: list[int]) -> int | None:
    """Bid from our ASU swing if we held the deed, capped by live-rent cash."""

    if env.phase != PHASE_AUCTION:
        return None
    bids = [a for a in legal if a != int(AuctionAction.PASS)]
    if not bids:
        return None
    square = getattr(env, "auction_property_id", None)
    if square is None:
        return None
    prop = env.properties.get(int(square))
    if prop is None:
        return None
    from ASU_FROZEN_TEACHER import evaluate_value

    before = float(evaluate_value(env, pid).total)
    saved = prop.owner
    prop.owner = pid
    try:
        after = float(evaluate_value(env, pid).total)
    finally:
        prop.owner = saved
    delta = after - before
    high = float(getattr(env, "auction_high_bid", 0) or 0)
    cash = float(env.players[pid].cash)
    headroom = min(delta, cash - cash_floor(env, pid)) - high
    if headroom <= 0:
        return int(AuctionAction.PASS) if int(AuctionAction.PASS) in legal else None
    for action, step in sorted(AUCTION_ACTION_TO_INCREMENT.items(), key=lambda kv: -kv[1]):
        if int(action) in bids and step <= headroom:
            return int(action)
    return int(AuctionAction.PASS) if int(AuctionAction.PASS) in legal else None
